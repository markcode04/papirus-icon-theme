# Arctic Apricity
#####A beautiful, modern gnome-shell theme
![Popover](https://github.com/apagajewski/Apricity_OS/blob/master/Apricity%20Screengrabs/Screenshot%20from%202015-07-05%2016-41-20.png?raw=true)
![Activities Overview](https://github.com/apagajewski/Apricity_OS/blob/master/Apricity%20Screengrabs/Screenshot%20from%202015-07-05%2016-45-03.png?raw=true)
![Calendar](https://github.com/apagajewski/Apricity_OS/blob/master/Apricity%20Screengrabs/Screenshot%20from%202015-07-05%2019-11-43.png?raw=true)
![Network Dialog](https://github.com/apagajewski/Apricity_OS/blob/master/Apricity%20Screengrabs/Screenshot%20from%202015-07-05%2019-11-57.png?raw=true)
